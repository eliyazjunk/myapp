<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ai_portal";

$conn = new mysqli("localhost", "root", "", "ai_portal");

?>