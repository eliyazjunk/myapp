<?php
@include 'config.php';

session_start();

//$conn = new mysqli("localhost", "root", "", "ai_portal");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else{
    echo "con ok";
}

if (isset($_POST['submit'])) {

    $is_match = $_POST['is_match'];
    $ticket_id = $_POST['ticket_id'];


//    echo $ful_name . $national_id . $phone_number . $request_number . $comment;
//    echo $is_match.$ticket_id;


    $sql = "UPDATE ticket SET match_flag='".$is_match."', status='Closed' WHERE id=".$ticket_id;

    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();

//    $sql = "INSERT INTO ticket (full_name, national_id, phone_number, request_number, description, pdf1) VALUES('$full_name','$national_id','$phone_number','$request_number', '$comment', '$file_name')";
//
//    if ($conn->query($sql) === TRUE) {
////        echo "New record created successfully";
//        header('Location: dashboard.php');
//
//    } else {
//        echo "Error: " . $sql . "<br>" . $conn->error;
//    }
//
//    $conn->close();




}


?>