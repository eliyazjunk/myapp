<!DOCTYPE html>
<html>
<head>
    <title>PDF Documents</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        iframe{
            height: 600px;
            width: 100%;
        }
    </style>
</head>
<body>

<nav>
    <div class="nav nav-tabs" id="nav-tab" role="tablist">
        <a class="nav-item nav-link active" id="nav-doc1-tab" data-toggle="tab" href="#nav-doc1" role="tab" aria-controls="nav-doc1" aria-selected="true">Document 1</a>
        <a class="nav-item nav-link" id="nav-doc2-tab" data-toggle="tab" href="#nav-doc2" role="tab" aria-controls="nav-doc2" aria-selected="false">Document 2</a>
        <a class="nav-item nav-link" id="nav-doc3-tab" data-toggle="tab" href="#nav-doc3" role="tab" aria-controls="nav-doc3" aria-selected="false">Document 3</a>
    </div>
</nav>
<div class="tab-content" id="nav-tabContent">
    <div class="tab-pane fade show active" id="nav-doc1" role="tabpanel" aria-labelledby="nav-doc1-tab">
        <iframe src="uploads/1.pdf" frameborder="0"></iframe>
    </div>
    <div class="tab-pane fade" id="nav-doc2" role="tabpanel" aria-labelledby="nav-doc2-tab">
        <iframe src="document2.pdf" frameborder="0"></iframe>
    </div>
    <div class="tab-pane fade" id="nav-doc3" role="tabpanel" aria-labelledby="nav-doc3-tab">
        <iframe src="document3.pdf" frameborder="0"></iframe>
    </div>
</div>

</body>
</html>
