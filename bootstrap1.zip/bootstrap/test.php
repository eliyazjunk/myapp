<!DOCTYPE html>
<html>
<head>
    <title>PDF Documents</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        iframe{
            height: 600px;
            width: 100%;
        }
    </style>
</head>
<body>
<nav>
    <div class="nav nav-tabs" id="nav-tab" role="tablist">
        <?php
        $dir = 'uploads/'; // specify the directory where your PDF files are stored
        $files = glob($dir.'*.pdf'); // get all PDF files from the directory
        foreach($files as $key=>$file){
            $filename = basename($file);
            $active = ($key == 0) ? 'active' : ''; // set the first tab as active
            echo '<a class="nav-item nav-link '.$active.'" id="nav-'.$key.'-tab" data-toggle="tab" href="#nav-'.$key.'" role="tab" aria-controls="nav-'.$key.'" aria-selected="'.(($key == 0) ? 'true' : 'false').'">'.$filename.'</a>';
        }
        ?>
    </div>
</nav>
<div class="tab-content" id="nav-tabContent">
    <?php
    foreach($files as $key=>$file){
        $filename = basename($file);
        $active = ($key == 0) ? 'show active' : ''; // set the first tab content as active
        echo '<div class="tab-pane fade '.$active.'" id="nav-'.$key.'" role="tabpanel" aria-labelledby="nav-'.$key.'-tab">';
        echo '<iframe src="'.$dir.$filename.'" frameborder="0"></iframe>';
        echo '</div>';
    }
    ?>
</div>
</body>
</html>
