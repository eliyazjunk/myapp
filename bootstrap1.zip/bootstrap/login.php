<?php

@include 'config.php';

// Start a session to keep track of the user's login status
session_start();



$conn = new mysqli($servername, $username, $password, $dbname);

// Check for errors in database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the username and password from the form
$username = $_POST['username'];
$password = $_POST['password'];
//$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Prepare the SQL statement to check the user's credentials
$stmt = $conn->prepare("SELECT * FROM user WHERE user_id = ? AND password = ?");

$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

// Check if the user exists in the database
if ($result->num_rows == 1) {
    // Authentication succeeded, redirect to the dashboard
    $_SESSION['loggedin'] = true;
    while($row = $result->fetch_assoc()) {
        $_SESSION['user_id'] = $row['user_id'];
    }
    header('Location: dashboard.php');


} else {
//    echo  "fail";
    // Authentication failed, redirect back to the login page with an error message
    header('Location: login_form.php?error=Invalid%20username%20or%20password');
}

// Close the database connection
$stmt->close();
$conn->close();
?>
<?php
