<?php
@include 'config.php';

session_start();

//$conn = new mysqli("localhost", "root", "", "ai_portal");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else{
    echo "con ok";
}

if (isset($_POST['submit'])) {

    $full_name = $_POST['full_name'];
    $national_id = $_POST['national_id'];
    $phone_number = $_POST['phone_number'];
    $request_number = $_POST['request_number'];
    $comment = $_POST['comment'];

//    echo $ful_name . $national_id . $phone_number . $request_number . $comment;
    echo "t1";

    $file_name = $_FILES['pdf1']['name'];
    $file_tmp = $_FILES['pdf1']['tmp_name'];
//    echo $file_name;
//    echo $file_tmp;
//
    move_uploaded_file($file_tmp, "uploads/".$file_name);
//    echo "File uploaded successfully.";


    $sql = "INSERT INTO ticket (full_name, national_id, phone_number, request_number, description, pdf1) VALUES('$full_name','$national_id','$phone_number','$request_number', '$comment', '$file_name')";

    if ($conn->query($sql) === TRUE) {
//        echo "New record created successfully";
        header('Location: dashboard.php');

    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();




}


?>