<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['loggedin'])){
    header('location:login_form.php');

}


?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Tanfeeth AI Portal</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">-->

    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">


</head>

<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-success topbar mb-4 static-top shadow">

                <h3 class="text-white ">Tanfeeth AI Portal</h3>

                <!-- Topbar Navbar -->

            </nav>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container">

                <!-- Page Heading -->
                <!--        <div class="d-sm-flex align-items-center justify-content-between mb-4">-->
                <!--          <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>-->
                <!--        </div>-->

                <!-- Content Row -->

                <div class="row container">
                    <div class="col d-flex justify-content-center">
                        <?php

                            echo "<h2>Welcome ".ucfirst($_SESSION['user_id']) ."</h2>";
                        ?>
                        <br>
                        <br>
                        <br>

                    </div>
                </div>


                <div class="row container">

                    <?php
                    if ($_SESSION['user_id']=='admin'){


                    ?>
                    <div class="col-xl-3 col-md-6 mb-4">
                        <form action="new_ticket.php" method="post">
                            <input class="btn btn-success btn-block" type="submit" value="New Ticket" >
                        </form>
                    </div>
                    <?php
                    }else{

                    ?>
                    <div class="col-xl-3 col-md-6 mb-4">

                    </div>
                    <?php
                    }
                    ?>

                    <div class="col-xl-3 col-md-6 mb-4">

                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">

                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <form action="logout.php" method="post">
                            <input class="btn btn-success btn-block" type="submit" value="Logout" >
                        </form>
                    </div>




                </div>


                <div class="row ">
                    <div class="container">

                        <!-- Page Heading -->
                        <br>

                        <div class="card shadow mb-4">
                            <!--                    <div class="card-header py-3">-->
                            <!--                        <h6 class="m-0 font-weight-bold text-primary">DataTables </h6>-->
                            <!--                    </div>-->
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                        <tr>
                                            <th>Ticket ID</th>
                                            <th>User ID</th>
                                            <th>Created Date</th>
                                            <th>Status</th>
                                        </tr>
                                        </thead>
                                        <tfoot>
                                        <tr>
                                            <th>Ticket ID</th>
                                            <th>User ID</th>
                                            <th>Created Date</th>
                                            <th>Status</th>
                                        </tr>
                                        </tfoot>

                                        <tbody>
<!--                                        here-->
<?php
// Create connection
//$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM ticket";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr>";

//        echo "<td><u>".$row["id"]."</u></td>";
//        echo "<input type="submit" class="link-button" /> </form>"
//        echo "<td> <form action='ticket_page.php'> <input class='btn btn-success' name='submit' type='submit'  value=".$row["id"]." ></form></td>";
        if($row['status']=='Open'){
            echo "<td><a href='ticket_page.php?id=".$row["id"]." '><u> ".$row["id"]." </u></a></td>";

        }else{
            echo "<td><a disabled='' ><u> ".$row["id"]." </u></a></td>";

        }

        echo "<td>".$_SESSION['user_id']."</td>";
        echo "<td>".$row["created_at"]."</td>";
        echo "<td>".$row["status"]."</td>";
        echo "</tr>";


//        echo "id: " . $row["id"]. " - Name: " . $row["created_at"]. " " . $row["status"]. "<br>";
    }
}
$conn->close();
?>



                                        </tbody>

                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>


                </div>


                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
<!--            <footer class="sticky-footer bg-white">-->
<!--                <div class="container my-auto">-->
<!--                    <div class="copyright text-center my-auto">-->
<!--                        <span>footer</span>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </footer>-->
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>



</body>

</html>